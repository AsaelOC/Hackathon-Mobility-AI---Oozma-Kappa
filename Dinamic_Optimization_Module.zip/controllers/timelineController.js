const { Client } = require("@googlemaps/google-maps-services-js");
const googlemaps = new Client({});
const settings = require("../database/settings");
const fs = require("fs");
const path = require("path");
const { time } = require("console");

async function addTrip(req, res) {
  const { arrivalTime, destination } = req.body;
  console.log(new Date(arrivalTime), destination);

  const tripDuration = await timeEstimate(destination);

  const departureTime = new Date(arrivalTime - tripDuration * 60000);
  //const departureTime = new Date(1764079200000);
  const loadTime = new Date(departureTime.getTime() - settings.loadDuration);

  const loadsAtThatMoment = happeningBetween(loadTime, departureTime);
  const availableAndenes = checkAvailableAndenes(loadsAtThatMoment);
  console.log("availableAndenes: ", availableAndenes);

  if (loadsAtThatMoment.length > 0) {
    if (availableAndenes.length > 0) {
      const andenId = availableAndenes[0];
      newTrip(
        0,
        andenId,
        departureTime.getTime(),
        loadTime.getTime(),
        arrivalTime,
        destination
      );
    } else {
    }
  }

  res.status(200).send({ message: "Trip added successfully" });
}

async function timeEstimate(destination) {
  try {
    const resultado = await googlemaps.directions({
      params: {
        origin: settings.site.join(","),
        destination: destination.join(","),
        mode: "driving",
        key: "AIzaSyB0BobSMDFBYjmedFJcNwnwns8K-DIKvGU",
      },
    });

    const seconds = resultado.data.routes[0].legs[0].duration.value;
    const minutosBase = seconds / 60;
    const horasBase = minutosBase / 60;

    const extraMediaHora = Math.floor(horasBase / 5) * 30;
    const extraOchoHoras = Math.floor(horasBase / 16) * 480;

    const minutosTotales = minutosBase + extraMediaHora + extraOchoHoras;

    return Math.round(minutosTotales);
  } catch (error) {
    throw new Error(error.message);
  }
}

function happeningBetween(loadStart, loadEnd) {
  const timelineDB = require("../database/timeline.json");

  return timelineDB.filter((trip) => {
    const tripLoadStart = new Date(trip.loadTime);
    const tripLoadEnd = new Date(trip.departureTime);
    return (
      (loadStart >= tripLoadStart && loadStart < tripLoadEnd) ||
      (new Date(loadStart.getTime() + loadEnd) > tripLoadStart &&
        new Date(loadStart.getTime() + loadEnd) <= tripLoadEnd)
    );
  });
}

function checkAvailableAndenes(loadsAtThatMoment) {
  const andenesDB = require("../database/andenes.json");

  const allAndenes = andenesDB.map((anden) => anden.id);
  const occupiedAndenes = loadsAtThatMoment.map((trip) => trip.andenId);
  const availableAndenes = allAndenes.filter(
    (anden) => !occupiedAndenes.includes(anden)
  );

  return availableAndenes;
}

function newTrip(
  truckId,
  andenId,
  departureTime,
  loadTime,
  arrivalTime,
  destination
) {
  const timelineDB = require("../database/timeline.json");
  const tripDuration = arrivalTime - departureTime;

  const trip = {
    id: timelineDB.length,
    truckId,
    andenId,
    arrivalTime,
    departureTime,
    loadTime,
    returnTime: arrivalTime + tripDuration,
    tripDuration,
    loadDuration: settings.loadDuration,
    unloadDuration: settings.unloadDuration,
    origin: settings.site,
    destination,
    driver: "Evan Patel",
    status: "scheduled",
  };

  timelineDB.push(trip);
  const timelinePath = path.join(__dirname, "../database/timeline.json");
  fs.writeFileSync(timelinePath, JSON.stringify(timelineDB, null, 2));
}

module.exports = {
  addTrip,
};
