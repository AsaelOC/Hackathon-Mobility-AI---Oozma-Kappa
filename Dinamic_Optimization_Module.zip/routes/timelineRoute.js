const express = require("express");
const router = express.Router();
const timelinesController = require("../controllers/timelineController");

router.post("/", timelinesController.addTrip);

module.exports = router;