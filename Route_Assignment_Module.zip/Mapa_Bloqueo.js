// Mapa_Bloqueo.js
const express = require("express");
const axios = require("axios");
const polyline = require("@mapbox/polyline");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// ⬅️ PON AQUÍ TU API KEY DE GOOGLE DIRECTIONS
const GOOGLE_API_KEY = "AIzaSyB0BobSMDFBYjmedFJcNwnwns8K-DIKvGU";

// Origen fijo en coordenadas (tu punto)
const ORIGEN_FIJO = {
  lat: 19.381567192044145,
  lng: -99.57546412959414
};

// Helper para convertir coords a string "lat,lng"
function coordsToString(coord) {
  return `${coord.lat},${coord.lng}`;
}

// ==========================
// 1. Modelo de bloqueos
// ==========================

const BLOQUEOS_EJEMPLO = [
  {
    nombre: "Bloqueo en carretera X",
    lat: 24.458992,
    lng: -100.334165,
    radio_m: 2000,
    delay_min: 300.0
  },
  {
    nombre: "Manifestación cerca de Y",
    lat: 19.9,
    lng: -99.2,
    radio_m: 300,
    delay_min: 10.0
  }
];

// ==========================
// 2. Funciones auxiliares
// ==========================

function distanciaMetros(lat1, lng1, lat2, lng2) {
  const R = 6371000.0;
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const dphi = ((lat2 - lat1) * Math.PI) / 180;
  const dlambda = ((lng2 - lng1) * Math.PI) / 180;

  const a =
    Math.sin(dphi / 2) ** 2 +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(dlambda / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function evaluarBloqueosEnRuta(rutaPuntos, bloqueos) {
  const nombresTocados = [];
  let delayTotal = 0.0;

  for (const p of rutaPuntos) {
    for (const b of bloqueos) {
      const d = distanciaMetros(p.lat, p.lng, b.lat, b.lng);
      if (d <= b.radio_m) {
        if (!nombresTocados.includes(b.nombre)) {
          nombresTocados.push(b.nombre);
          delayTotal += Number(b.delay_min || 0.0);
        }
      }
    }
  }

  return { nombresTocados, delayTotal };
}

// ==========================
// 3. Google Directions API
// ==========================

async function obtenerRutasDesdeGoogle(origen, destino, apiKey, alternatives = true) {
  const url = "https://maps.googleapis.com/maps/api/directions/json";
  const params = {
    origin: origen,
    destination: destino,
    mode: "driving",
    key: apiKey,
    alternatives: alternatives ? "true" : "false"
  };

  const resp = await axios.get(url, { params });
  return resp.data;
}

async function obtenerMejorRuta(origen, destino, apiKey, bloqueos) {
  const data = await obtenerRutasDesdeGoogle(origen, destino, apiKey, true);

  const status = data.status;
  if (status !== "OK") {
    return {
      exito: false,
      error: `Error de Google Directions: ${status}`
    };
  }

  const rutas = data.routes || [];
  console.log(`\n➡ Google devolvió ${rutas.length} rutas alternativas`);

  const rutasInfo = [];

  rutas.forEach((ruta, idx) => {
    const poly = ruta.overview_polyline.points;
    const decoded = polyline.decode(poly); // [[lat,lng], ...]
    const puntos = decoded.map(([lat, lng]) => ({ lat, lng }));

    const distancia_m = ruta.legs.reduce(
      (acc, leg) => acc + leg.distance.value,
      0
    );
    const duracion_s = ruta.legs.reduce(
      (acc, leg) => acc + leg.duration.value,
      0
    );
    const tiempo_base_minutos = duracion_s / 60.0;

    const origen_r = ruta.legs[0].start_address;
    const destino_r = ruta.legs[ruta.legs.length - 1].end_address;
    const duracion_texto = ruta.legs[0].duration.text;

    const { nombresTocados, delayTotal } = evaluarBloqueosEnRuta(
      puntos,
      bloqueos
    );
    const tiempo_total_minutos = tiempo_base_minutos + delayTotal;

    const infoRuta = {
      indice: idx,
      puntos_ruta: puntos,
      distancia_km: distancia_m / 1000.0,
      tiempo_base_minutos,
      delay_bloqueos_min: delayTotal,
      tiempo_total_minutos,
      tiempo_total_texto: duracion_texto,
      origen: origen_r,
      destino: destino_r,
      raw: ruta,
      bloqueos_encontrados: nombresTocados
    };

    rutasInfo.push(infoRuta);

    console.log(`  Ruta ${idx}:`);
    console.log(`    Tiempo base: ${tiempo_base_minutos.toFixed(2)} min`);
    console.log(`    Delay bloqueos: ${delayTotal.toFixed(2)} min`);
    console.log(`    Tiempo total: ${tiempo_total_minutos.toFixed(2)} min`);
    console.log(`    Bloqueos tocados: ${nombresTocados.join(", ") || "Ninguno"}\n`);
  });

  if (rutasInfo.length === 0) {
    return {
      exito: false,
      error: "No se encontraron rutas entre origen y destino"
    };
  }

  const rutasSinBloqueo = rutasInfo.filter(
    r => r.bloqueos_encontrados.length === 0
  );
  const rutasConBloqueo = rutasInfo.filter(
    r => r.bloqueos_encontrados.length > 0
  );

  let mejor;
  if (rutasSinBloqueo.length > 0) {
    mejor = rutasSinBloqueo.reduce((a, b) =>
      a.tiempo_base_minutos < b.tiempo_base_minutos ? a : b
    );
    console.log("✔ Elegida ruta SIN bloqueos");
  } else {
    mejor = rutasConBloqueo.reduce((a, b) =>
      a.tiempo_total_minutos < b.tiempo_total_minutos ? a : b
    );
    console.log(
      "⚠ Todas las rutas pasan por bloqueos, elegida la más rápida considerando delay"
    );
  }

  const ruta_evita_bloqueos = mejor.bloqueos_encontrados.length === 0;

  return {
    exito: true,
    origen: mejor.origen,
    destino: mejor.destino,
    distancia_km: mejor.distancia_km,
    tiempo_total_texto: mejor.tiempo_total_texto,
    tiempo_total_minutos: mejor.tiempo_total_minutos,
    tiempo_base_minutos: mejor.tiempo_base_minutos,
    delay_bloqueos_min: mejor.delay_bloqueos_min,
    puntos_ruta: mejor.puntos_ruta,
    ruta_evita_bloqueos,
    bloqueos_encontrados: mejor.bloqueos_encontrados,
    raw: mejor.raw
  };
}

// ==========================
// 4. API REST
// ==========================

// Ruta clásica con origen/destino como texto (por si la sigues usando)
app.get("/api/ruta", async (req, res) => {
  try {
    const origen = req.query.origen;
    const destino = req.query.destino;

    if (!origen || !destino) {
      return res.status(400).json({
        exito: false,
        error: "Parámetros 'origen' y 'destino' son requeridos"
      });
    }

    const resultado = await obtenerMejorRuta(
      origen,
      destino,
      GOOGLE_API_KEY,
      BLOQUEOS_EJEMPLO
    );

    resultado.bloqueos = BLOQUEOS_EJEMPLO;

    res.json(resultado);
  } catch (err) {
    console.error(err);
    res.status(500).json({ exito: false, error: "Error interno del servidor" });
  }
});

// NUEVA ruta: origen fijo (ORIGEN_FIJO) y destino como coordenadas
// Ejemplo: GET /api/ruta_coords?dest_lat=25.67&dest_lng=-100.30
app.get("/api/ruta_coords", async (req, res) => {
  try {
    const destLat = parseFloat(req.query.dest_lat);
    const destLng = parseFloat(req.query.dest_lng);

    if (Number.isNaN(destLat) || Number.isNaN(destLng)) {
      return res.status(400).json({
        exito: false,
        error: "Parámetros 'dest_lat' y 'dest_lng' válidos son requeridos"
      });
    }

    const origenStr = coordsToString(ORIGEN_FIJO);
    const destinoStr = `${destLat},${destLng}`;

    const resultado = await obtenerMejorRuta(
      origenStr,
      destinoStr,
      GOOGLE_API_KEY,
      BLOQUEOS_EJEMPLO
    );

    resultado.bloqueos = BLOQUEOS_EJEMPLO;
    resultado.origen_fijo = ORIGEN_FIJO;

    res.json(resultado);
  } catch (err) {
    console.error(err);
    res.status(500).json({ exito: false, error: "Error interno del servidor" });
  }
});

// ==========================
// 5. Frontend estático
// ==========================

app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Servidor escuchando en http://localhost:${PORT}`);
  console.log(`Abre: http://localhost:${PORT}/`);
});
