// Escala y configuración
const PIXELS_PER_HOUR = 120;       // ancho por hora
const PIXELS_PER_MINUTE = PIXELS_PER_HOUR / 60;
const START_HOUR = 0;
const END_HOUR = 72;              
const TOTAL_HOURS = END_HOUR - START_HOUR;
const GRID_WIDTH = TOTAL_HOURS * PIXELS_PER_HOUR;

//PROVEEDORES DE DESTINO
const proveedores = [
  "ABBOTT LABORATORIES DE MEXICO S.A. DE C.V.",
  "AEROBAL",
  "ASG OPERATIONS S. de R.L. de CV",
  "AVON COSMETICS MANUFACTURING",
  "Beckman Coutler de México",
  "BODEGA EXPORTEC",
  "CHURCH & DWIGHT S DE RL DE CV",
  "CLOROX DE MEXICO S. DE R.L. DE C.V.",
  "COMERCIAL IMPORTADORA, S DE RL DE CV",
  "CON ALIMENTOS S.A DE C.V.",
  "COSBEL S.A. DE C.V.",
  "DOBOS, S.A. DE C.V.",
  "EXXONMOBIL MEXICO S.A. DE C.V.",
  "GANADEROS PRODUCTORES DE LECHE PURA",
  "GRUPO ALPHALAB DE MEXICO HOME AND BEAUTY CARE  S.A. DE C.V.",
  "HALEON CONSUMER HEALTHCARE MEXICO",
  "Logistic Center",
  "MARY KAY COSMETICS DE MEXICO S.A. DE C.V.",
  "MCCORMICK DE MEXICO S.A. DE C.V.  z",
  "MCCORMICK DE MEXICO S.A. DE C.V. S",
  "NESTLE MEXICO - COATEPEC",
  "NESTLE MEXICO S.A. DE C.V. - PLANTA CHIAPAS",
  "NESTLE MEXICO S.A. DE C.V. - PLANTA VERACRUZ",
  "P&G - NAUCALPAN",
  "P&G - PLANTA Naucalpan",
  "P&G - PLANTA VALLEJO",
  "PERFETTI VAN MELLE MEXICO S.A. DE C.V.",
  "PROPIMEX S.DE R.L. DE C.V. (CUAUTITLÁN)",
  "PROPIMEX S.DE R.L. DE C.V. (ZINACANTEPEC)",
  "QUALAMEX S.A. DE C.V.",
  "RB MANUFACTURING LLC",
  "RB SALUTE MEXICO - PLANTA COYOACAN",
  "RB SALUTE MEXICO S.A. DE C.V.",
  "RECKITT BENCKISER MEXICO S.A. DE C.V.",
  "S.C. JOHNSON AND SON S.A. DE C.V.",
  "SABORMEX S.A.P.I. DE C.V.",
  "SANCHEZ Y MARTIN SA DE CV"
];



// Datos iniciales
let docks = proveedores.map((name, index) => ({
  id: index + 1,
  name: name
}));


let transports = [
  { id:'JD', color:'#f50000ff' },
  { id:'CALZONZIN', color:'#0ce726ff' },
  { id:'ALP', color:'#4100f5ff' }
];

// shipments will be cargados desde el backend (persistencia en shipments.json)
let shipments = [];

// Maps / Location selection state
let map = null;
let marker = null;
let autocomplete = null;
let geocoder = null;
let selectedLocation = null; // { lat, lng, address }

async function loadShipments(){
  try{
    const res = await fetch('/api/shipments');
    if(!res.ok) throw new Error('Error al obtener traslados');
    const data = await res.json();
    shipments = Array.isArray(data) ? data : [];
    renderShipments();
  }catch(e){
    console.error('loadShipments:', e);
  }
}

// Helpers de tiempo
function timeToMinutes(t) {
  const [h,m] = t.split(':').map(Number);
  return h*60 + m;
}
function minutesToTime(mins){
  const clamped = Math.max(0, mins);
  const h = Math.floor(clamped/60) % 24;
  const m = clamped % 60;
  return `${pad(h)}:${pad(m)}`;
}
function pad(n){ return n.toString().padStart(2,'0'); }

// Generar timestamps de inicio y fin
function generarTimestamps(fecha, horaInicio, minInicio, duracionMin, tipo) {
  const inicio = new Date(fecha);
  inicio.setHours(horaInicio);
  inicio.setMinutes(minInicio);
  inicio.setSeconds(0);
  inicio.setMilliseconds(0);

  const tsInicio = inicio.getTime();
  const fin = new Date(tsInicio + duracionMin * 60000);
  const tsFin = fin.getTime();

  return {
    end: tsFin,
    type: tipo
  };
}

// Fecha / hora helpers
function parseDateAndTime(dateStr, timeStr){
  // dateStr: 'YYYY-MM-DD', timeStr: 'HH:MM'
  if(!dateStr) return null;
  const [y,m,d] = dateStr.split('-').map(Number);
  const [hh,mm] = (timeStr||'00:00').split(':').map(Number);
  return new Date(y, m-1, d, hh, mm, 0, 0);
}
function formatDateTime(dt){
  if(!dt) return '';
  const y = dt.getFullYear();
  const m = pad(dt.getMonth()+1);
  const d = pad(dt.getDate());
  const hh = pad(dt.getHours());
  const mm = pad(dt.getMinutes());
  return `${y}-${m}-${d} ${hh}:${mm}`;
}
// Convert a timestamp (ms) into minutes offset since grid start (today at START_HOUR)
function getMinutesSinceGridStart(ts){
  if(!ts) return 0;
  const base = new Date();
  base.setHours(START_HOUR,0,0,0);
  const diff = Number(ts) - base.getTime();
  return Math.floor(diff / (60*1000));
}
function dayDiffFromToday(dateStr){
  if(!dateStr) return 0;
  const today = new Date();
  const t0 = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const parts = dateStr.split('-').map(Number);
  const d = new Date(parts[0], parts[1]-1, parts[2]);
  const diff = Math.round((d - t0) / (24*60*60*1000));
  return diff;
}

// Inicialización DOM
document.addEventListener('DOMContentLoaded', async () => {
  initClock();
  renderGridStructure();
  renderDocksAndRows();
  populateSelects();
  await loadShipments();
  renderColorPicker();
  setupUI();
  updateCurrentTimeLine();
  setInterval(updateCurrentTimeLine, 60*1000);
});

// Google Maps callback (loaded via script tag with callback=initMap)
window.initMap = function(){
  // default center (Mexico City)
  const defaultCenter = { lat: 19.3815, lng: -99.5754 };
  geocoder = new google.maps.Geocoder();
  map = new google.maps.Map(document.getElementById('location-map'), {
    center: defaultCenter,
    zoom: 12,
    disableDefaultUI: true,
    // cooperative lets the page scroll with wheel/trackpad unless user explicitly interacts with the map (helps avoid blocking page scroll)
    gestureHandling: 'cooperative'
  });

  marker = new google.maps.Marker({ map, draggable: true });
  marker.setVisible(false);

  const input = document.getElementById('input-location-search');
  if(!input) return;

  // Autocomplete to help select places
  autocomplete = new google.maps.places.Autocomplete(input, { fields: ['geometry','formatted_address','name'] });
  autocomplete.addListener('place_changed', () => {
    const place = autocomplete.getPlace();
    if(!place.geometry) return;
    const lat = place.geometry.location.lat();
    const lng = place.geometry.location.lng();
    const address = place.formatted_address || place.name || input.value;
    selectedLocation = { lat, lng, address };
    marker.setPosition({ lat, lng });
    marker.setVisible(true);
    map.setCenter({ lat, lng });
    map.setZoom(15);
    document.getElementById('input-location-lat').value = lat;
    document.getElementById('input-location-lng').value = lng;
  });

  // when dragging marker update coords
  marker.addListener('dragend', () => {
    const pos = marker.getPosition();
    if(!pos) return;
    const lat = pos.lat();
    const lng = pos.lng();
    selectedLocation = { lat, lng, address: selectedLocation ? selectedLocation.address : '' };
    document.getElementById('input-location-lat').value = lat;
    document.getElementById('input-location-lng').value = lng;
  });

  // button to force geocode/search (lupa)
  const searchBtn = document.getElementById('btn-location-find');
  if(searchBtn){
    searchBtn.addEventListener('click', (e)=>{
      e.preventDefault();
      const q = input.value && input.value.trim();
      if(!q) return;
      geocoder.geocode({ address: q }, (results, status) => {
        if(status === 'OK' && results[0]){
          const r = results[0];
          const loc = r.geometry.location;
          const lat = loc.lat();
          const lng = loc.lng();
          selectedLocation = { lat, lng, address: r.formatted_address };
          marker.setPosition({ lat, lng });
          marker.setVisible(true);
          map.setCenter({ lat, lng });
          map.setZoom(15);
          document.getElementById('input-location-lat').value = lat;
          document.getElementById('input-location-lng').value = lng;
        }else{
          alert('No se encontró la ubicación: ' + status);
        }
      });
    });
  }

  // Allow user to click on map to select a location directly
  map.addListener('click', (ev) => {
    try{
      const lat = ev.latLng.lat();
      const lng = ev.latLng.lng();
      marker.setPosition(ev.latLng);
      marker.setVisible(true);
      selectedLocation = { lat, lng, address: '' };
      // reverse geocode to get a human-readable address when possible
      if(geocoder){
        geocoder.geocode({ location: ev.latLng }, (results, status) => {
          if(status === 'OK' && results && results[0]){
            const addr = results[0].formatted_address;
            selectedLocation.address = addr;
            const searchInput = document.getElementById('input-location-search');
            if(searchInput) searchInput.value = addr;
          }
          // always store coords in hidden inputs
          const latEl = document.getElementById('input-location-lat');
          const lngEl = document.getElementById('input-location-lng');
          if(latEl) latEl.value = lat;
          if(lngEl) lngEl.value = lng;
        });
      }else{
        const latEl = document.getElementById('input-location-lat');
        const lngEl = document.getElementById('input-location-lng');
        if(latEl) latEl.value = lat;
        if(lngEl) lngEl.value = lng;
      }
    }catch(e){
      console.warn('Click handler error', e);
    }
  });
};

// Reloj
function initClock(){
  const timeEl = document.getElementById('clock-time');
  const dateEl = document.getElementById('clock-date');
  function tick(){
    const now = new Date();
    timeEl.textContent = now.toLocaleTimeString('es-MX',{hour12:false});
    const opts = { weekday:'long', year:'numeric', month:'long', day:'numeric' };
    const s = now.toLocaleDateString('es-ES', opts);
    dateEl.textContent = s.charAt(0).toUpperCase() + s.slice(1);
  }
  tick();
  setInterval(tick,1000);
}

// Render estructura de horas y cuerpo con fecha real
function renderGridStructure() {
  const header = document.getElementById("time-header");
  const body = document.getElementById("grid-body");
  header.innerHTML = "";
  body.innerHTML = "";

  header.style.width = GRID_WIDTH + "px";
  body.style.width = GRID_WIDTH + "px";

  // Día base (hoy)
  const today = new Date();

  for (let h = START_HOUR; h < END_HOUR; h++) {
    const slot = document.createElement("div");
    slot.className = "time-slot";
    slot.style.minWidth = PIXELS_PER_HOUR + "px";

    // hora real (0–23 cada día)
    const hour = h % 24;

    // calcular fecha correspondiente sumando días
    const date = new Date(today);
    date.setDate(today.getDate() + Math.floor(h / 24));

    // dar formato a fecha
    const options = { day: '2-digit', month: 'short', year: 'numeric' };
    const formattedDate = date.toLocaleDateString('es-MX', options);

    slot.innerHTML = `
      ${pad(hour)}:00
      <br>
      <small>${formattedDate}</small>
    `;

    header.appendChild(slot);
  }
}



// Render docks column + grid rows
function renderDocksAndRows(){
  const docksContainer = document.getElementById('docks-container');
  const gridBody = document.getElementById('grid-body');

  // conservar header
  docksContainer.innerHTML = '<div class="docks-header">RUTAS</div>';
  gridBody.innerHTML = '';

  docks.forEach(d => {
    // label
    const label = document.createElement('div');
    label.className = 'dock-label';
    label.textContent = d.name;
    docksContainer.appendChild(label);

    // row
    const row = document.createElement('div');
    row.className = 'dock-row';
    row.id = `dock-row-${d.id}`;
    // fondo con guías por hora (opcional)
    row.style.backgroundSize = `${PIXELS_PER_HOUR}px 100%`;
    gridBody.appendChild(row);
  });
}
// Dibuja los shipments dentro de cada row
function renderShipments(){
  // eliminar existentes
  document.querySelectorAll('.shipment-block').forEach(e=>e.remove());

  shipments.forEach(s => {
    const row = document.getElementById(`dock-row-${s.dockId}`);
    if(!row) return;

    // Calculos base usando timestamps (ms). Support legacy startDate/startTime.
    let startTs = s.startTs;
    if(!startTs && s.startDate && s.startTime){
      const dt = parseDateAndTime(s.startDate, s.startTime);
      startTs = dt ? dt.getTime() : null;
    }
    // fallback: if no startTs but arrivalTs and durations present, estimate start
    if(!startTs && s.arrivalTs && (s.trip || s.load)){
      startTs = Number(s.arrivalTs) - (Number(s.trip||0) + Number(s.load||0)) * 60 * 1000;
    }
    const startMinSinceGrid = getMinutesSinceGridStart(startTs);
    const left = (startMinSinceGrid) * PIXELS_PER_MINUTE;

    const loadW   = (s.load || 0) * PIXELS_PER_MINUTE;
    const tripW   = (s.trip || 0) * PIXELS_PER_MINUTE;
    const unloadW = (s.unload || 0) * PIXELS_PER_MINUTE;
    const returnW = (s.returnTrip || s.trip || 0) * PIXELS_PER_MINUTE;

    const totalWidth = loadW + tripW + unloadW + returnW;

    // contenedor principal
    const block = document.createElement('div');
    block.className = 'shipment-block';
    block.style.left = `${left}px`;
    block.style.width = `${Math.max(totalWidth, 40)}px`;

    const transport = transports.find(t=>t.id===s.transportId);
    const color = transport ? transport.color : '#3b82f6';

    // === Segmento 1: CARGA ===
    const segLoad = document.createElement('div');
    segLoad.className = 'block-left';
    segLoad.style.width = `${loadW}px`;
    segLoad.textContent = `Carga ${s.load||0}m`;
    

    // === Segmento 2: TRASLADO ===
    const segTrip = document.createElement('div');
    segTrip.className = 'block-center';
    segTrip.style.background = color;
    segTrip.style.width = `${tripW}px`;
    segTrip.innerHTML = `
      <div style="font-weight:700">${s.transportId}</div>
      <div class="block-small">${s.trip||0}m</div>
    `;

    // === Segmento 3: DESCARGA ===
    const segUnload = document.createElement('div');
    segUnload.className = 'block-right';
    segUnload.style.width = `${unloadW}px`;
    segUnload.style.background = '#f97316';
    segUnload.textContent = `Descarga ${s.unload||0}m`;

    // === Segmento 4: REGRESO ===
    const segReturn = document.createElement('div');
    segReturn.className = 'block-center';
    segReturn.style.width = `${returnW}px`;
    segReturn.style.background = '#64748b'; // gris
    segReturn.innerHTML = `<div class="block-small">Regreso ${s.returnTrip||s.trip||0}m</div>`;

    // Insertar los segmentos en el bloque
    block.appendChild(segLoad);
    block.appendChild(segTrip);
    block.appendChild(segUnload);
    block.appendChild(segReturn);

    // botón eliminar individual
    const delBtn = document.createElement('button');
    delBtn.className = 'shipment-delete';
    delBtn.title = 'Eliminar traslado';
    delBtn.textContent = '✕';
    // estilo inline básico para que sea visible sin tocar CSS
    delBtn.style.position = 'absolute';
    delBtn.style.top = '4px';
    delBtn.style.right = '4px';
    delBtn.style.zIndex = '20';
    delBtn.style.border = 'none';
    delBtn.style.background = 'rgba(0,0,0,0.25)';
    delBtn.style.color = '#fff';
    delBtn.style.padding = '2px 6px';
    delBtn.style.cursor = 'pointer';
    delBtn.style.borderRadius = '4px';
    delBtn.addEventListener('click', (ev)=>{ ev.stopPropagation(); deleteShipment(s.id); });
    block.appendChild(delBtn);

    row.appendChild(block);
  });
}

// Eliminar traslado por id (frontend)
async function deleteShipment(id){
  if(!confirm('¿Eliminar este traslado? Esta acción no se puede deshacer.')) return;
  try{
    const res = await fetch(`/api/shipments/${encodeURIComponent(id)}`, { method: 'DELETE' });
    if(!res.ok){
      const e = await res.json().catch(()=>({}));
      alert('Error al eliminar: ' + (e.error || res.statusText));
      return;
    }
    await loadShipments();
  }catch(err){
    console.error('deleteShipment error', err);
    alert('Error al comunicarse con el servidor');
  }
}

// Vaciar todos los traslados
async function clearAllShipments(){
  if(!confirm('¿Eliminar TODOS los traslados? Se recomienda hacer un backup primero.')) return;
  try{
    const res = await fetch('/api/shipments?confirm=true', { method: 'DELETE' });
    if(!res.ok){
      const e = await res.json().catch(()=>({}));
      alert('Error al vaciar: ' + (e.error || res.statusText));
      return;
    }
    await loadShipments();
  }catch(err){
    console.error('clearAllShipments error', err);
    alert('Error al comunicarse con el servidor');
  }
}



// Linea de tiempo actual
function updateCurrentTimeLine(){
  const now = new Date();
  const minutesSinceMidnight = now.getHours()*60 + now.getMinutes();
  const pos = (minutesSinceMidnight - START_HOUR*60) * PIXELS_PER_MINUTE;
  const line = document.getElementById('current-time-indicator');
  const label = document.getElementById('current-time-label');
  const gridScroll = document.getElementById('grid-scroll-area');
  const timeHeader = document.getElementById('time-header');
  const docksContainer = document.getElementById('docks-container');
  
  if(!line || !gridScroll || !timeHeader || !docksContainer){
    return;
  }

  // 1. Calcular la posición horizontal (left)
  const gridRect = gridScroll.getBoundingClientRect();
  
  // leftViewport: Posición fija en el viewport, ajustada por el scroll horizontal
  const leftViewport = Math.round(gridRect.left + pos - gridScroll.scrollLeft);

  // 2. Calcular la posición vertical (top) fija
  // topPos: Usa el borde inferior del timeHeader. Dado que time-header es sticky/estático en esa posición, 
  // su coordenada 'bottom' es estable en el viewport.
  const topPos = timeHeader.getBoundingClientRect().bottom;


  // 3. Mostrar/Ocultar y aplicar estilos
  if(leftViewport < gridRect.left - 50 || leftViewport > gridRect.right + 50){
    line.style.display = 'none';
  } else {
    line.style.display = 'block';
    
    // Posición fija horizontal
    line.style.left = `${leftViewport}px`;
    
    // Posición vertical fija
    line.style.top = `${topPos}px`;
    
    // Altura: Desde topPos hasta el final de la ventana
    line.style.height = `${window.innerHeight - topPos}px`; 
    
    label.textContent = now.toLocaleTimeString('es-MX',{hour:'2-digit',minute:'2-digit'});
  }
}
// UI / eventos
function setupUI(){
  document.getElementById('btn-new-shipment').addEventListener('click', ()=> openModal('modal-shipment'));
  document.getElementById('btn-new-transport').addEventListener('click', ()=> openModal('modal-transport'));
  // open add dock modal
  const addDockBtn = document.getElementById('btn-add-dock');
  if(addDockBtn) addDockBtn.addEventListener('click', ()=> openModal('modal-add-dock'));
  document.querySelectorAll('[data-close]').forEach(btn=>{
    btn.addEventListener('click', e=>{
      const id = btn.getAttribute('data-close');
      closeModal(id);
    });
  });

  document.getElementById('create-shipment').addEventListener('click', createShipment);
  document.getElementById('create-transport').addEventListener('click', createTransport);
  // create dock handler
  const createDockBtn = document.getElementById('create-dock');
  if(createDockBtn) createDockBtn.addEventListener('click', createDock);

  const clearBtn = document.getElementById('btn-clear-shipments');
  if(clearBtn) clearBtn.addEventListener('click', clearAllShipments);

  // inputs preview
  ['input-load','input-trip','input-unload','input-arrival','input-arrival-date'].forEach(id=>{
    const el = document.getElementById(id);
    if(el) el.addEventListener('input', updatePreviewTime);
  });

  // fill selects now
  populateSelects();
  updatePreviewTime();

  // Sync vertical scroll: use single scrollbar on the main grid and mirror position to docks column
  const gridScroll = document.getElementById('grid-scroll-area');
  const docksContainer = document.getElementById('docks-container');
  if(gridScroll && docksContainer){
    gridScroll.addEventListener('scroll', ()=>{
      docksContainer.scrollTop = gridScroll.scrollTop;
    });
    // If user uses mouse wheel over the docks column, forward it to the main grid
    docksContainer.addEventListener('wheel', (ev)=>{
      if(ev.deltaY === 0) return;
      gridScroll.scrollTop += ev.deltaY;
      ev.preventDefault();
    }, { passive: false });
  }
}

// MODALES
function openModal(id){
  document.getElementById(id).classList.remove('hidden');
  if(id==='modal-shipment'){
    // establecer fecha por defecto (hoy) si no hay valor
    const dateEl = document.getElementById('input-arrival-date');
    if(dateEl && !dateEl.value){
      const now = new Date();
      const def = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`;
      dateEl.value = def;
    }
    updatePreviewTime();
    // ensure map initializes/resizes and recenters when modal is visible
    setTimeout(()=>{
      try{
        // if Google Maps is loaded but map not yet created, initialize it now
        if(!map && window.google && window.google.maps && typeof window.initMap === 'function'){
          // initMap will create the map and related handlers
          window.initMap();
        }
        if(map && window.google && window.google.maps){
          // trigger resize and recenter if needed
          try{ google.maps.event.trigger(map,'resize'); }catch(e){}
          if(selectedLocation){
            map.setCenter({ lat: selectedLocation.lat, lng: selectedLocation.lng });
            map.setZoom(15);
            if(marker) { marker.setPosition({ lat: selectedLocation.lat, lng: selectedLocation.lng }); marker.setVisible(true); }
          }
        }
      }catch(e){ /* ignore if maps not ready */ }
    }, 300);
  }
}
function closeModal(id){
  document.getElementById(id).classList.add('hidden');
}

// SELECTS
function populateSelects(){
  const transSel = document.getElementById('input-transport');
  const dockSel = document.getElementById('input-dock');
  if(!transSel || !dockSel) return;
  transSel.innerHTML = '';
  transports.forEach(t=>{
    const o = document.createElement('option');
    o.value = t.id;
    // show company and type when available
    const company = t.company ? ` ${t.company}` : '';
    const type = t.type ? ` ${t.type}` : '';
    o.textContent = `${t.id}${company}${type}`;
    transSel.appendChild(o);
  });
  dockSel.innerHTML = '';
  docks.forEach(d=>{
    const o = document.createElement('option'); o.value = d.id; o.textContent = d.name; dockSel.appendChild(o);
  });

  // preview color set
  const first = transports[0];
  if(first) document.getElementById('preview-trip-color').style.backgroundColor = first.color;
}

// Preview tiempo
function updatePreviewTime(){
  const load = parseInt(document.getElementById('input-load').value) || 0;
  const trip = parseInt(document.getElementById('input-trip').value) || 0;
  const unload = parseInt(document.getElementById('input-unload').value) || 0;
  const total = load + trip + unload + trip;
  const arrivalTimeEl = document.getElementById('input-arrival');
  const arrivalDateEl = document.getElementById('input-arrival-date');
  let preview = `Tiempo total: ${total} minutos`;
  if(arrivalDateEl && arrivalDateEl.value && arrivalTimeEl && arrivalTimeEl.value){
    const arrivalDT = parseDateAndTime(arrivalDateEl.value, arrivalTimeEl.value);
    const startDT = new Date(arrivalDT.getTime() - (trip + load) * 60 * 1000);
    preview += ` • Llegada: ${formatDateTime(arrivalDT)} • Inicio estimado: ${formatDateTime(startDT)}`;
  } else if(arrivalTimeEl && arrivalTimeEl.value){
    const arrivalMin = timeToMinutes(arrivalTimeEl.value);
    const startMin = Math.max(0, arrivalMin - trip - load);
    preview += ` • Inicio estimado: ${minutesToTime(startMin)}`;
  }
  document.getElementById('total-time-preview').textContent = preview;
}

// CREAR NUEVO TRASLADO
async function createShipment(){
const transportId = document.getElementById("input-transport").value;
const dockId = document.getElementById("input-dock").value;

// timestamps
const dateStr = document.getElementById("input-arrival-date").value;
const timeStr = document.getElementById("input-arrival").value;
const arrivalTs = new Date(`${dateStr}T${timeStr}:00`).getTime();

// tiempos
const load = Number(document.getElementById("input-load").value);
const trip = Number(document.getElementById("input-trip").value);
const unload = Number(document.getElementById("input-unload").value);

// coordenadas
const lat = parseFloat(document.getElementById("input-location-lat").value) || 0;
  const lng = parseFloat(document.getElementById("input-location-lng").value) || 0;

// payload que si funciona
const payload = {
    transportId,
    dockId: Number(dockId),
    arrivalTs,
    load,
    trip,
    unload,
    destination: [lat, lng],
  };

console.log("Payload enviado:", payload);

fetch("/api/shipments", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(payload)
})


  .then(r => r.json())
  .then(data => {
    console.log("Backend:", data);
    closeModal("modal-shipment");
    loadShipments();
  })
  .catch(err => console.error("Error:", err));



  // Attach selected location coordinates (if any)
  try{
    const latVal = document.getElementById('input-location-lat') ? document.getElementById('input-location-lat').value : null;
    const lngVal = document.getElementById('input-location-lng') ? document.getElementById('input-location-lng').value : null;
    if(selectedLocation || (latVal && lngVal)){
      payload.locationLat = selectedLocation ? Number(selectedLocation.lat) : Number(latVal);
      payload.locationLng = selectedLocation ? Number(selectedLocation.lng) : Number(lngVal);
      payload.locationAddress = selectedLocation ? selectedLocation.address : (document.getElementById('input-location-search') ? document.getElementById('input-location-search').value : '');
    }
  }catch(e){ console.warn('No se pudieron adjuntar coordenadas:', e); }

  try{
    const res = await fetch('/api/shipments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if(!res.ok){
      const e = await res.json().catch(()=>({}));
      alert('Error al guardar traslado: ' + (e.error||res.statusText));
      return;
    }
    // recargar lista desde backend
    await loadShipments();
    closeModal('modal-shipment');
  }catch(err){
    console.error('createShipment error', err);
    alert('Error al comunicarse con el servidor');
  }
}

// COLOR PICKER para nuevo transporte
const COLORS = ['#3B82F6','#EF4444','#10B981','#F59E0B','#8B5CF6','#EC4899','#06B6D4','#F97316','#14B8A6','#6366F1','#84CC16','#F43F5E'];
let selectedColor = COLORS[0];

function renderColorPicker(){
  const grid = document.getElementById('color-picker-grid');
  grid.innerHTML = '';
  COLORS.forEach(c=>{
    const sw = document.createElement('div');
    sw.className = 'color-swatch' + (c===selectedColor ? ' selected' : '');
    sw.style.background = c;
    sw.addEventListener('click', ()=> {
      selectedColor = c;
      renderColorPicker();
    });
    grid.appendChild(sw);
  });
}

// CREAR TRANSPORTE
function createTransport(){
  const id = document.getElementById('new-transport-id').value.trim();
  if(!id){ alert('Ingrese matrícula'); return; }

  const type = document.getElementById('new-transport-type').value;
  const year = Number(document.getElementById('new-transport-year').value) || null;
  const mileage = Number(document.getElementById('new-transport-mileage').value) || 0;
  const tires = document.getElementById('new-transport-tires').value;
  const shocks = document.getElementById('new-transport-shocks').value;
  const suspension = document.getElementById('new-transport-suspension').value;
  const company = document.getElementById('new-transport-company').value;

  const newTransport = {
    id,
    type,
    year,
    mileage,
    tiresState: tires,
    shocksState: shocks,
    suspensionState: suspension,
    company,
    color: selectedColor
  };

  transports.push(newTransport);
  populateSelects();
  renderColorPicker();
  closeModal('modal-transport');

  // clear fields
  document.getElementById('new-transport-id').value = '';
  document.getElementById('new-transport-year').value = '';
  document.getElementById('new-transport-mileage').value = '';
  // keep selected color as-is

  alert(`Transporte ${id} agregado correctamente`);
}

// CREAR NUEVA RUTA / ANDÉN
function createDock(){
  const name = document.getElementById('new-dock-name').value.trim();
  if(!name){ alert('Ingrese el nombre de la ruta'); return; }
  const status = document.getElementById('new-dock-status').value;
  const address = document.getElementById('new-dock-address').value.trim();
  const lat = parseFloat(document.getElementById('new-dock-lat').value) || null;
  const lng = parseFloat(document.getElementById('new-dock-lng').value) || null;

  // determine new id (max existing id + 1)
  const maxId = docks.reduce((m,d)=> Math.max(m, d.id||0), 0);
  const newId = maxId + 1;

  const dock = {
    id: newId,
    name,
    status,
    address: address || null,
    lat: lat,
    lng: lng
  };

  docks.push(dock);
  // re-render rows and update selects
  renderDocksAndRows();
  populateSelects();
  closeModal('modal-add-dock');

  // clear inputs
  document.getElementById('new-dock-name').value = '';
  document.getElementById('new-dock-address').value = '';
  document.getElementById('new-dock-lat').value = '';
  document.getElementById('new-dock-lng').value = '';

  alert(`Ruta agregada: ${name}`);
}
