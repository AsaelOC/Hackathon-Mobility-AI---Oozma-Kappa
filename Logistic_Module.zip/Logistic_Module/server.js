const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(__dirname, 'shipments.json');

app.use(express.json());

// Servir carpeta "public"
app.use(express.static(path.join(__dirname, 'public')));

// Servir index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

function readShipments(){
  try{
    if(!fs.existsSync(DATA_FILE)) return [];
    const raw = fs.readFileSync(DATA_FILE,'utf8');
    return JSON.parse(raw || '[]');
  }catch(e){
    console.error('Error leyendo shipments:', e);
    return [];
  }
}

function parseDateAndTimeToTs(dateStr, timeStr){
  // dateStr: 'YYYY-MM-DD', timeStr: 'HH:MM'
  if(!dateStr) return null;
  const [y,m,d] = dateStr.split('-').map(Number);
  const [hh,mm] = (timeStr||'00:00').split(':').map(Number);
  return new Date(y, m-1, d, hh, mm, 0, 0).getTime();
}

function writeShipments(arr){
  try{
    fs.writeFileSync(DATA_FILE, JSON.stringify(arr, null, 2), 'utf8');
    return true;
  }catch(e){
    console.error('Error escribiendo shipments:', e);
    return false;
  }
}

// API: listar traslados
app.get('/api/shipments', (req, res) => {
  const data = readShipments();
  res.json(data);
});

// API: crear traslado
app.post('/api/shipments', (req, res) => {
  const body = req.body || {};
  // Accept either timestamps (startTs / arrivalTs) or legacy startDate/startTime + arrivalDate/arrivalTime
  if( !body.arrivalTs || !body.destination){
    return res.status(400).json({ error: 'Faltan campos requeridos (arrivalTs, destination)' });
  }
  const list = readShipments();
  // Normalize to timestamps (milliseconds)
  let startTs = body.startTs;
  if(!startTs && body.startDate && body.startTime){
    startTs = parseDateAndTimeToTs(body.startDate, body.startTime);
  }
  // if only arrival and durations provided, compute start
  if(!startTs && body.arrivalTs && (body.trip || body.load)){
    startTs = Number(body.arrivalTs) - (Number(body.trip||0) + Number(body.load||0)) * 60 * 1000;
  }

  let arrivalTs = body.arrivalTs;
  if(!arrivalTs && body.arrivalDate && body.arrivalTime){
    arrivalTs = parseDateAndTimeToTs(body.arrivalDate, body.arrivalTime);
  }
  // if arrival missing but start present, estimate arrival
  if(!arrivalTs && startTs && (body.trip || body.load)){
    arrivalTs = Number(startTs) + (Number(body.load||0) + Number(body.trip||0)) * 60 * 1000;
  }

  const item = Object.assign({ id: Date.now() }, body);
  // replace legacy date/time fields with numeric timestamps
  if(startTs) item.startTs = Number(startTs);
  if(arrivalTs) item.arrivalTs = Number(arrivalTs);
  delete item.startDate; delete item.startTime; delete item.arrivalDate; delete item.arrivalTime;
  list.push(item);
  const ok = writeShipments(list);
  if(!ok) return res.status(500).json({ error: 'No se pudo guardar' });
  res.status(201).json(item);
});

// API: borrar un traslado por id
app.delete('/api/shipments/:id', (req, res) => {
  const id = req.params.id;
  const list = readShipments();
  const idNum = isNaN(Number(id)) ? id : Number(id);
  const idx = list.findIndex(x => x.id === idNum);
  if(idx === -1){
    return res.status(404).json({ error: 'No encontrado' });
  }
  const removed = list.splice(idx,1)[0];
  const ok = writeShipments(list);
  if(!ok) return res.status(500).json({ error: 'No se pudo actualizar' });
  res.json({ deleted: removed });
});

// borrar todos los traslados (requiere confirm query param)
app.delete('/api/shipments', (req, res) => {
  const confirm = req.query.confirm;
  if(!(confirm === '1' || confirm === 'true')){
    return res.status(400).json({ error: 'Confirme la eliminación masiva con ?confirm=true' });
  }
  const ok = writeShipments([]);
  if(!ok) return res.status(500).json({ error: 'No se pudo vaciar' });
  res.json({ deletedAll: true });
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
